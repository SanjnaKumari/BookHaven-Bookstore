import React from 'react';
function Checkout() {
    return (
        <div>
            This is Checkout Page!!!
        </div>
    );
}

export default Checkout;